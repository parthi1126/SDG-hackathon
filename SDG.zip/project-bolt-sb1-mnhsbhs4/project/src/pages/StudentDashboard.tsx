import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { BarChart2, Book, MessageCircle, Trophy, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import StudentProgress from '../components/StudentProgress';
import Rankings from '../components/Rankings';
import ChatBot from '../components/ChatBot';

export default function StudentDashboard() {
  const { user, signOut } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const location = useLocation();

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const fetchProfile = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    if (!error && data) {
      setProfile(data);
    }
  };

  const navigation = [
    { name: 'Progress', path: '/student', icon: BarChart2 },
    { name: 'Rankings', path: '/student/rankings', icon: Trophy },
    { name: 'Chat Assistant', path: '/student/chat', icon: MessageCircle },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="flex h-screen">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-lg">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-center h-16 px-4 border-b">
              <Book className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-lg font-semibold">Exam Tracker</span>
            </div>
            
            <nav className="flex-1 px-4 py-4">
              {navigation.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.name}
                    to={item.path}
                    className={`flex items-center px-4 py-2 mt-2 text-gray-600 rounded-lg hover:bg-gray-100 ${
                      location.pathname === item.path ? 'bg-indigo-50 text-indigo-600' : ''
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="ml-3">{item.name}</span>
                  </Link>
                );
              })}
            </nav>

            <div className="p-4 border-t">
              <button
                onClick={() => signOut()}
                className="flex items-center px-4 py-2 text-gray-600 rounded-lg hover:bg-gray-100 w-full"
              >
                <LogOut className="h-5 w-5" />
                <span className="ml-3">Logout</span>
              </button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-auto">
          <div className="p-8">
            <Routes>
              <Route path="/" element={<StudentProgress />} />
              <Route path="/rankings" element={<Rankings />} />
              <Route path="/chat" element={<ChatBot />} />
            </Routes>
          </div>
        </div>
      </div>
    </div>
  );
}