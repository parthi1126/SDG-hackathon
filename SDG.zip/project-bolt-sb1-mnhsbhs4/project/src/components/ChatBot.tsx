import React, { useState, useEffect, useRef } from 'react';
import { Send } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export default function ChatBot() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      fetchMessages();
    }
  }, [user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    const { data, error } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: true });

    if (!error && data) {
      setMessages(data);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setIsLoading(true);
    const userMessage = input;
    setInput('');

    // Simulate AI response (in a real app, this would call your AI service)
    const aiResponse = generateResponse(userMessage);

    const { data, error } = await supabase
      .from('chat_messages')
      .insert([
        {
          user_id: user.id,
          message: userMessage,
          response: aiResponse
        }
      ])
      .select();

    if (!error && data) {
      setMessages([...messages, data[0]]);
    }

    setIsLoading(false);
  };

  // Simple response generation (replace with actual AI integration)
  const generateResponse = (message: string) => {
    const responses = [
      "Based on your performance, I recommend focusing more on numerical ability topics.",
      "You're doing well! Keep practicing with more mock tests to improve further.",
      "Consider reviewing the fundamentals of this topic before moving to advanced concepts.",
      "Your progress is impressive! Let's work on time management next.",
      "I suggest trying some practice problems in the areas where you scored lower."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  return (
    <div className="flex flex-col h-[calc(100vh-2rem)]">
      <div className="bg-white rounded-lg shadow-md p-6 flex-1 flex flex-col">
        <div className="flex-1 overflow-y-auto mb-4">
          <div className="space-y-4">
            {messages.map((msg, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-end">
                  <div className="bg-indigo-600 text-white rounded-lg py-2 px-4 max-w-md">
                    {msg.message}
                  </div>
                </div>
                <div className="flex justify-start">
                  <div className="bg-gray-200 rounded-lg py-2 px-4 max-w-md">
                    {msg.response}
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </div>

        <form onSubmit={handleSubmit} className="flex items-center space-x-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask for study recommendations..."
            className="flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-indigo-600 text-white rounded-lg p-2 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <Send className="h-5 w-5" />
          </button>
        </form>
      </div>
    </div>
  );
}