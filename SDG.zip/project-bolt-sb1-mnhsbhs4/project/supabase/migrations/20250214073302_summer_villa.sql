/*
  # Initial Schema Setup for Exam Tracker

  1. New Tables
    - `profiles`
      - User profiles with role (student/instructor)
    - `subjects`
      - Main subjects/topics for exams
    - `topics`
      - Detailed topics within subjects
    - `practice_tests`
      - Tests taken by students
    - `test_results`
      - Detailed results per topic
    - `chat_messages`
      - Store chat interactions
    
  2. Security
    - Enable RLS on all tables
    - Add policies for data access
*/

-- Create tables
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email text NOT NULL,
  full_name text,
  role text NOT NULL CHECK (role IN ('student', 'instructor')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid REFERENCES subjects(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS practice_tests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES profiles(id),
  subject_id uuid REFERENCES subjects(id),
  test_date timestamptz DEFAULT now(),
  total_score integer NOT NULL,
  max_score integer NOT NULL
);

CREATE TABLE IF NOT EXISTS test_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id uuid REFERENCES practice_tests(id) ON DELETE CASCADE,
  topic_id uuid REFERENCES topics(id),
  score integer NOT NULL,
  max_score integer NOT NULL
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id),
  message text NOT NULL,
  response text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE topics ENABLE ROW LEVEL SECURITY;
ALTER TABLE practice_tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE test_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Public profiles are viewable by everyone" ON profiles
  FOR SELECT USING (true);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Subjects viewable by everyone" ON subjects
  FOR SELECT USING (true);

CREATE POLICY "Instructors can create subjects" ON subjects
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'instructor'
    )
  );

CREATE POLICY "Topics viewable by everyone" ON topics
  FOR SELECT USING (true);

CREATE POLICY "Students can view own test results" ON practice_tests
  FOR SELECT USING (auth.uid() = student_id);

CREATE POLICY "Students can create own test results" ON practice_tests
  FOR INSERT WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Students can view own detailed results" ON test_results
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM practice_tests
      WHERE practice_tests.id = test_id
      AND practice_tests.student_id = auth.uid()
    )
  );

CREATE POLICY "Users can view own chat messages" ON chat_messages
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create chat messages" ON chat_messages
  FOR INSERT WITH CHECK (auth.uid() = user_id);