<?php
session_start();
include 'db.php'; // Include database connection

// Get JSON input from the frontend
$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'];
$password = $data['password'];
$role = $data['role']; // 'student' or 'teacher'

// Validate input
if (!$email || !$password || !$role) {
    echo json_encode(["error" => "Missing required fields"]);
    exit;
}

// Query the database
$stmt = $conn->prepare("SELECT id, password_hash FROM Users WHERE email = ? AND user_type = ?");
$stmt->bind_param("ss", $email, $role);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    
    // Verify the password
    if (password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $role;
        echo json_encode(["message" => "Login successful", "role" => $role]);
    } else {
        echo json_encode(["error" => "Invalid password"]);
    }
} else {
    echo json_encode(["error" => "User not found"]);
}

$stmt->close();
$conn->close();
?>
