<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "exam_tracker_db";
$port = 3306;

// Create connection
$con = new mysqli($host, $user, $password, $dbname, $port);

// Check connection
if ($con->connect_error) {
    die("❌ Connection failed: " . $con->connect_error);
} else {
    echo "✅ Connected successfully to MySQL!";
}
?>