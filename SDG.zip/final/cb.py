from flask import Flask, render_template, request
import google.generativeai as genai

app = Flask(__name__)

# Configure the API key
genai.configure(api_key="AIzaSyBX2tfVVBNA-BHFDnDTbtNqCdGZFkmLI04")

# Create the model
generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
    model_name="gemini-1.5-flash",
    generation_config=generation_config,
)

chat_session = model.start_chat(history=[])

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        user_message = request.form['message']
        if user_message.lower() == "exit":
            bot_reply = "Exiting chat..."
        else:
            try:
                response = chat_session.send_message(user_message)
                bot_reply = response.text
            except Exception as e:
                bot_reply = f"An error occurred: {str(e)}"
        return render_template('hoem page1.html', user_message=user_message, bot_reply=bot_reply)
    return render_template('home page1.html')

if __name__ == '__main__':
    app.run(debug=True)
