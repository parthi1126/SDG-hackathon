// script.js
const apiKey = "AIzaSyAL8SqEN6-bLc2veRRdPuUqx6s80g8jix0s";

function sendMessage() {
    const input = document.querySelector(".chat-input");
    const message = input.value;

    if (message.trim() === "") return;

    displayMessage(message, "user-message");

    // Call your API service here using the API key
    fetch(`https://api.example.com/chatbot?message=${encodeURIComponent(message)}&key=${apiKey}`)
        .then(response => response.json())
        .then(data => {
            const botMessage = data.reply; // Adjust based on your API response format
            displayMessage(botMessage, "bot-message");
        })
        .catch(error => console.error("Error:", error));

    input.value = "";
}

function displayMessage(message, className) {
    const chatBody = document.querySelector(".chat-body");
    const chatMessage = document.createElement("div");
    chatMessage.classList.add("chat-message", className);
    chatMessage.textContent = message;
    chatBody.appendChild(chatMessage);
    chatBody.scrollTop = chatBody.scrollHeight;
}
