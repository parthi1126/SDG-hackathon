import React, { useState, useEffect } from 'react';
import { Book, Users, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

export default function InstructorDashboard() {
  const { user, signOut } = useAuth();
  const [students, setStudents] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [newSubject, setNewSubject] = useState({ name: '', description: '' });

  useEffect(() => {
    if (user) {
      fetchStudents();
      fetchSubjects();
    }
  }, [user]);

  const fetchStudents = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select(`
        *,
        practice_tests (
          id,
          total_score,
          max_score,
          subjects (name)
        )
      `)
      .eq('role', 'student');

    if (!error && data) {
      setStudents(data);
    }
  };

  const fetchSubjects = async () => {
    const { data, error } = await supabase
      .from('subjects')
      .select('*')
      .order('name');

    if (!error && data) {
      setSubjects(data);
    }
  };

  const handleAddSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const { data, error } = await supabase
      .from('subjects')
      .insert([
        {
          name: newSubject.name,
          description: newSubject.description,
          created_by: user.id
        }
      ]);

    if (!error) {
      setNewSubject({ name: '', description: '' });
      fetchSubjects();
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="flex h-screen">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-lg">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-center h-16 px-4 border-b">
              <Book className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-lg font-semibold">Instructor Panel</span>
            </div>

            <div className="p-4 border-t mt-auto">
              <button
                onClick={() => signOut()}
                className="flex items-center px-4 py-2 text-gray-600 rounded-lg hover:bg-gray-100 w-full"
              >
                <LogOut className="h-5 w-5" />
                <span className="ml-3">Logout</span>
              </button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-auto p-8">
          <div className="grid grid-cols-1 gap-8">
            {/* Students Overview */}
            <div>
              <div className="flex items-center mb-4">
                <Users className="h-6 w-6 text-indigo-600 mr-2" />
                <h2 className="text-2xl font-bold text-gray-900">Students Overview</h2>
              </div>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Email
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Tests Taken
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Avg. Score
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {students.map((student) => {
                      const testCount = student.practice_tests?.length || 0;
                      const avgScore = testCount
                        ? student.practice_tests.reduce((acc: number, test: any) => 
                            acc + (test.total_score / test.max_score), 0) / testCount * 100
                        : 0;

                      return (
                        <tr key={student.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {student.full_name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {student.email}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {testCount}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {avgScore.toFixed(1)}%
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Add Subject Form */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Add New Subject</h2>
              <div className="bg-white rounded-lg shadow-md p-6">
                <form onSubmit={handleAddSubject} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Subject Name
                    </label>
                    <input
                      type="text"
                      value={newSubject.name}
                      onChange={(e) => setNewSubject({ ...newSubject, name: e.target.value })}
                      className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Description
                    </label>
                    <textarea
                      value={newSubject.description}
                      onChange={(e) => setNewSubject({ ...newSubject, description: e.target.value })}
                      className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                      rows={3}
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Add Subject
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}